/**
 * GP Limit Dates - Frontend Scripts
 */

( function( $ ) {

    window.GPLimitDates = {

        init: function( formId, fieldId, data ) {

            $( document ).bind( 'gform_post_render', function() {

                var $input = $( '#input_' + formId + '_' + fieldId );

                $input.change( function() {
                    GPLimitDates.validateDate( $( this ), fieldId, data );
                } );

                GPLimitDates.validateDate( $input, fieldId, data );

            } );

        },

        isDateInRange: function( date, min, max ) {

            if( GPLimitDates.isValidDateObject( min ) && GPLimitDates.isValidDateObject( max ) ) {
                return date >= min && date <= max;
            } else if( GPLimitDates.isValidDateObject( min ) ) {
                return date >= min;
            } else if( GPLimitDates.isValidDateObject( max ) ) {
                return date <= max;
            }

            return true;
        },

        strToTime: function( text, now ) {
            /*discuss at: http://phpjs.org/functions/strtotime/
             version: 1109.2016
             original by: Caio Ariede (http://caioariede.com)
             improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
             improved by: Caio Ariede (http://caioariede.com)
             improved by: A. Matías Quezada (http://amatiasq.com)
             improved by: preuter
             improved by: Brett Zamir (http://brett-zamir.me)
             improved by: Mirko Faber
             input by: David
             bugfixed by: Wagner B. Soares
             bugfixed by: Artur Tchernychev
             bugfixed by: Stephan Bösch-Plepelits (http://github.com/plepe)*/
            var parsed, match, today, year, date, days, ranges, len, times, regex, i, fail = false;

            if (!text) {
                return fail;
            }

            // Unecessary spaces
            text = text.replace(/^\s+|\s+$/g, '')
                .replace(/\s{2,}/g, ' ')
                .replace(/[\t\r\n]/g, '')
                .toLowerCase();

            // in contrast to php, js Date.parse function interprets:
            // dates given as yyyy-mm-dd as in timezone: UTC,
            // dates with "." or "-" as MDY instead of DMY
            // dates with two-digit years differently
            // etc...etc...
            // ...therefore we manually parse lots of common date formats
            match = text.match(
                /^(\d{1,4})([\-\.\/\:])(\d{1,2})([\-\.\/\:])(\d{1,4})(?:\s(\d{1,2}):(\d{2})?:?(\d{2})?)?(?:\s([A-Z]+)?)?$/);

            if (match && match[2] === match[4]) {
                if (match[1] > 1901) {
                    switch (match[2]) {
                        case '-':
                        {
                            // YYYY-M-D
                            if (match[3] > 12 || match[5] > 31) {
                                return fail;
                            }

                            return new Date(match[1], parseInt(match[3], 10) - 1, match[5],
                                    match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                        }
                        case '.':
                        {
                            // YYYY.M.D is not parsed by strtotime()
                            return fail;
                        }
                        case '/':
                        {
                            // YYYY/M/D
                            if (match[3] > 12 || match[5] > 31) {
                                return fail;
                            }

                            return new Date(match[1], parseInt(match[3], 10) - 1, match[5],
                                    match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                        }
                    }
                } else if (match[5] > 1901) {
                    switch (match[2]) {
                        case '-':
                        {
                            // D-M-YYYY
                            if (match[3] > 12 || match[1] > 31) {
                                return fail;
                            }

                            return new Date(match[5], parseInt(match[3], 10) - 1, match[1],
                                    match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                        }
                        case '.':
                        {
                            // D.M.YYYY
                            if (match[3] > 12 || match[1] > 31) {
                                return fail;
                            }

                            return new Date(match[5], parseInt(match[3], 10) - 1, match[1],
                                    match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                        }
                        case '/':
                        {
                            // M/D/YYYY
                            if (match[1] > 12 || match[3] > 31) {
                                return fail;
                            }

                            return new Date(match[5], parseInt(match[1], 10) - 1, match[3],
                                    match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                        }
                    }
                } else {
                    switch (match[2]) {
                        case '-':
                        {
                            // YY-M-D
                            if (match[3] > 12 || match[5] > 31 || (match[1] < 70 && match[1] > 38)) {
                                return fail;
                            }

                            year = match[1] >= 0 && match[1] <= 38 ? +match[1] + 2000 : match[1];
                            return new Date(year, parseInt(match[3], 10) - 1, match[5],
                                    match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                        }
                        case '.':
                        {
                            // D.M.YY or H.MM.SS
                            if (match[5] >= 70) {
                                // D.M.YY
                                if (match[3] > 12 || match[1] > 31) {
                                    return fail;
                                }

                                return new Date(match[5], parseInt(match[3], 10) - 1, match[1],
                                        match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                            }
                            if (match[5] < 60 && !match[6]) {
                                // H.MM.SS
                                if (match[1] > 23 || match[3] > 59) {
                                    return fail;
                                }

                                today = new Date();
                                return new Date(today.getFullYear(), today.getMonth(), today.getDate(),
                                        match[1] || 0, match[3] || 0, match[5] || 0, match[9] || 0) / 1000;
                            }

                            // invalid format, cannot be parsed
                            return fail;
                        }
                        case '/':
                        {
                            // M/D/YY
                            if (match[1] > 12 || match[3] > 31 || (match[5] < 70 && match[5] > 38)) {
                                return fail;
                            }

                            year = match[5] >= 0 && match[5] <= 38 ? +match[5] + 2000 : match[5];
                            return new Date(year, parseInt(match[1], 10) - 1, match[3],
                                    match[6] || 0, match[7] || 0, match[8] || 0, match[9] || 0) / 1000;
                        }
                        case ':':
                        {
                            // HH:MM:SS
                            if (match[1] > 23 || match[3] > 59 || match[5] > 59) {
                                return fail;
                            }

                            today = new Date();
                            return new Date(today.getFullYear(), today.getMonth(), today.getDate(),
                                    match[1] || 0, match[3] || 0, match[5] || 0) / 1000;
                        }
                    }
                }
            }

            // other formats and "now" should be parsed by Date.parse()
            if (text === 'now') {
                return now === null || isNaN(now) ? new Date()
                    .getTime() / 1000 | 0 : now | 0;
            }
            if (!isNaN(parsed = Date.parse(text))) {
                return parsed / 1000 | 0;
            }
            // Browsers != Chrome have problems parsing ISO 8601 date strings, as they do
            // not accept lower case characters, space, or shortened time zones.
            // Therefore, fix these problems and try again.
            // Examples:
            //   2015-04-15 20:33:59+02
            //   2015-04-15 20:33:59z
            //   2015-04-15t20:33:59+02:00
            if (match = text.match(/^([0-9]{4}-[0-9]{2}-[0-9]{2})[ t]([0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]+)?)([\+-][0-9]{2}(:[0-9]{2})?|z)/)) {
                // fix time zone information
                if (match[4] == 'z') {
                    match[4] = 'Z';
                }
                else if (match[4].match(/^([\+-][0-9]{2})$/)) {
                    match[4] = match[4] + ':00';
                }

                if (!isNaN(parsed = Date.parse(match[1] + 'T' + match[2] + match[4]))) {
                    return parsed / 1000 | 0;
                }
            }

            date = now ? new Date(now * 1000) : new Date();
            days = {
                'sun': 0,
                'mon': 1,
                'tue': 2,
                'wed': 3,
                'thu': 4,
                'fri': 5,
                'sat': 6
            };
            ranges = {
                'yea': 'FullYear',
                'mon': 'Month',
                'day': 'Date',
                'hou': 'Hours',
                'min': 'Minutes',
                'sec': 'Seconds'
            };

            function lastNext(type, range, modifier) {
                var diff, day = days[range];

                if (typeof day !== 'undefined') {
                    diff = day - date.getDay();

                    if (diff === 0) {
                        diff = 7 * modifier;
                    } else if (diff > 0 && type === 'last') {
                        diff -= 7;
                    } else if (diff < 0 && type === 'next') {
                        diff += 7;
                    }

                    date.setDate(date.getDate() + diff);
                }
            }

            function process(val) {
                var splt = val.split(' '), // Todo: Reconcile this with regex using \s, taking into account browser issues with split and regexes
                    type = splt[0],
                    range = splt[1].substring(0, 3),
                    typeIsNumber = /\d+/.test(type),
                    ago = splt[2] === 'ago',
                    num = (type === 'last' ? -1 : 1) * (ago ? -1 : 1);

                if (typeIsNumber) {
                    num *= parseInt(type, 10);
                }

                if (ranges.hasOwnProperty(range) && !splt[1].match(/^mon(day|\.)?$/i)) {
                    return date['set' + ranges[range]](date['get' + ranges[range]]() + num);
                }

                if (range === 'wee') {
                    return date.setDate(date.getDate() + (num * 7));
                }

                if (type === 'next' || type === 'last') {
                    lastNext(type, range, num);
                } else if (!typeIsNumber) {
                    return false;
                }

                return true;
            }

            times = '(years?|months?|weeks?|days?|hours?|minutes?|min|seconds?|sec' +
            '|sunday|sun\\.?|monday|mon\\.?|tuesday|tue\\.?|wednesday|wed\\.?' +
            '|thursday|thu\\.?|friday|fri\\.?|saturday|sat\\.?)';
            regex = '([+-]?\\d+\\s' + times + '|' + '(last|next)\\s' + times + ')(\\sago)?';

            match = text.match(new RegExp(regex, 'gi'));
            if (!match) {
                return fail;
            }

            for (i = 0, len = match.length; i < len; i++) {
                if (!process(match[i])) {
                    return fail;
                }
            }

            // ECMAScript 5 only
            // if (!match.every(process))
            //    return false;

            return (date.getTime() / 1000);
        },

        getModifiedDate: function( modifier, date ) {
            return new Date( GPLimitDates.strToTime( modifier, date.getTime() / 1000 ) * 1000 );
        },

        getDateValue: function( value, key, fieldId, formId, data ) {

            var date      = null,
                isFieldId = GPLimitDates.isNumeric( value );

            if( value == '{today}' ) {
                date = new Date();
            } else if( isFieldId ) {
                var $input = $( '#input_' + formId + '_' + value );
                date = GPLimitDates.parseDate( $input.val(), fieldId, data );
            } else {
                date = new Date( value );
            }

            var modifier = key == 'minDate' ? data[ fieldId ].minDateMod : data[ fieldId ].maxDateMod;
            if( modifier ) {
                date = GPLimitDates.getModifiedDate( modifier, date );
            }

            // only convert to server time for {today}
            if( value == '{today}' ) {
                date = GPLimitDates.convertDateToServerTime( date, GPLimitDatesData.serverTimezoneOffset );
                date.setHours( 0, 0, 0, 0 );
            }

            return date;
        },

        setMinMaxDate: function( $input, fieldId, formId, data ) {

            var minFieldIds = data[ fieldId ].setsMinDateFor,
                maxFieldIds = data[ fieldId ].setsMaxDateFor;

            if( minFieldIds ) {
                $.each( minFieldIds, function( index, minFieldId ) {
                    GPLimitDates.setMinDate( $input.datepicker( 'getDate' ), minFieldId, formId, data );
                } );
            }

            if( maxFieldIds ) {
                $.each( maxFieldIds, function( index, maxFieldId ) {
                    GPLimitDates.setMaxDate( $input.datepicker( 'getDate' ), maxFieldId, formId, data );
                } );
            }

        },

        setMinDate: function( selectedDate, fieldId, formId, data ) {

            if( ! selectedDate ) {
                return;
            }

            var $input   = $( '#input_' + formId + '_' + fieldId ),
                modifier = data[ fieldId ].minDateMod,
                date     = selectedDate;

            if( modifier ) {
                date = GPLimitDates.getModifiedDate( modifier, date );
            }

            $input.datepicker( 'option', 'minDate', date );

            return date;
        },

        setMaxDate: function( selectedDate, fieldId, formId, data ) {

            if( ! selectedDate ) {
                return;
            }

            var $input   = $( '#input_' + formId + '_' + fieldId ),
                modifier = data[ fieldId ].maxDateMod,
                date     = selectedDate;

            if( modifier ) {
                date = GPLimitDates.getModifiedDate( modifier, new Date( date ) );
            }

            $input.datepicker( 'option', 'maxDate', date );

            return date;
        },

        isDateShown: function( date, data, fieldId ) {

            if( ! date ) {
                return [ true ];
            }

            var daysOfWeek       = data[ fieldId ].daysOfWeek,
                exceptions       = data[ fieldId ].exceptions,
                dateString       = jQuery.datepicker.formatDate( 'mm/dd/yy', date ),
                day              = date.getDay(),
                isValidDayOfWeek = typeof daysOfWeek != 'object' || daysOfWeek.length <= 0 || daysOfWeek.indexOf( day ) != -1,
                isExcepted       = false,
                shouldDisplay    = true;

            if( exceptions.indexOf( dateString ) != -1 ) {
                var inDateRange = GPLimitDates.isDateInRange( date, $( this ).datepicker( 'option', 'minDate' ), $( this ).datepicker( 'option', 'maxDate' ) );
                isExcepted      = true;
                shouldDisplay   = ! ( inDateRange && isValidDayOfWeek );
            }

            return [ ( isExcepted && shouldDisplay ) || ( ! isExcepted && isValidDayOfWeek ) ];
        },

        validateDate: function( $input, fieldId, data ) {

            var date          = $input.datepicker( 'getDate' ),
                formattedDate = $.datepicker.formatDate( $input.datepicker( 'option', 'dateFormat' ), date ),
                dateVal       = $input.val();

            if( dateVal != formattedDate ) {
                $input.val( formattedDate );
            }

            var $container = $input.parents( '.ginput_container' ),
                $error     = $container.find( 'span.gpld-error-message' );

            var isValid    = ! date || ( GPLimitDates.isDateShown( date, data, fieldId )[0] && GPLimitDates.isDateInRange( date, $input.datepicker( 'option', 'minDate' ), $input.datepicker( 'option', 'maxDate' ) ) );

            if( ! isValid ) {

                if( $error.length <= 0 ) {
                    var iconSvgUrl = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTc5MiIgaGVpZ2h0PSIxNzkyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogPGc+CiAgPHRpdGxlPkxheWVyIDE8L3RpdGxlPgogIDxwYXRoIGZpbGw9IiM3OTAwMDAiIGQ9Im0xNDkwLDEzMjJxMCw0MCAtMjgsNjhsLTEzNiwxMzZxLTI4LDI4IC02OCwyOHQtNjgsLTI4bC0yOTQsLTI5NGwtMjk0LDI5NHEtMjgsMjggLTY4LDI4dC02OCwtMjhsLTEzNiwtMTM2cS0yOCwtMjggLTI4LC02OHQyOCwtNjhsMjk0LC0yOTRsLTI5NCwtMjk0cS0yOCwtMjggLTI4LC02OHQyOCwtNjhsMTM2LC0xMzZxMjgsLTI4IDY4LC0yOHQ2OCwyOGwyOTQsMjk0bDI5NCwtMjk0cTI4LC0yOCA2OCwtMjh0NjgsMjhsMTM2LDEzNnEyOCwyOCAyOCw2OHQtMjgsNjhsLTI5NCwyOTRsMjk0LDI5NHEyOCwyOCAyOCw2OHoiIGlkPSJzdmdfMSIvPgogPC9nPgo8L3N2Zz4=';
                    $error = $( '<span class="gpld-error-message" style="background: transparent url( \'' + iconSvgUrl + '\' ) no-repeat center left; background-size: 18px; padding-left: 19px; color: #790000; font-size: 12px;">' +
                        GPLimitDatesData.strings.invalidDate + '</span>' );
                    $container.append( $error );
                }

                $error.show();
                $input.addClass( 'gpld-error' );

            } else {

                $error.hide();
                $input.removeClass( 'gpld-error' );

            }

        },

        convertDateToServerTime: function( date, offset ) {

            var serverTimezoneOffset = offset,
                userTime             = date,
                userTimezoneOffset   = userTime.getTimezoneOffset();

            var utcTime = new Date( userTime );
            utcTime.setHours( utcTime.getHours() + Math.floor( userTimezoneOffset / 60 ) );

            var serverTime = new Date( utcTime );
            serverTime.setHours( serverTime.getHours() + Math.floor( serverTimezoneOffset / 60 ) );

            return serverTime;
        },

        isNumeric: function( value ) {
            return ! isNaN( parseFloat( value ) ) && isFinite( value ) ;
        },

        isValidDateObject: function( date ) {
            return Object.prototype.toString.call( date ) === '[object Date]' && ! isNaN( date.getTime() );
        },

        /**
         * Parse a JS date object from a date value based on a specific field's properties. Based on code from the
         * GWDates class.
         */
        parseDate: function( date, fieldId, data ) {

            var timestamp  = false,
                formatBits = data[ fieldId ].dateFormat.split( '_' ),
                mdy        = formatBits[0],
                separator  = formatBits[1] ? formatBits[1] : 'slash',
                sepChars   = { slash: '/', dot: '.', dash: '-' },
                sepChar    = sepChars[ separator ];

            var dateArr     = date.split( sepChar ),
                month       = dateArr[ mdy.indexOf( 'm' ) ],
                day         = dateArr[ mdy.indexOf( 'd' ) ],
                year        = dateArr[ mdy.indexOf( 'y' ) ],
                missingData = ! month || ! day || ! year;

            date = new Date( year, month - 1, day, 0, 0, 0, 0 );

            return date;
        }

    };

    gform.addFilter( 'gform_datepicker_options_pre_init', function( optionsObj, formId, fieldId ) {

        var data = window[ 'GPLimitDatesData' + formId];

        if( ! data[ fieldId ] ) {
            return optionsObj;
        }

        var onClose = optionsObj.onClose,
            $dp     = $( '#ui-datepicker-div' );

        // modify optionsObj
        $.each( data[ fieldId ], function( key, value ) {

            if( ! value || value.length <= 0 ) {
                return true; // continue
            }

            switch( key ) {
                case 'minDate':
                    optionsObj.minDate = GPLimitDates.getDateValue( value, key, fieldId, formId, data );
                    break;
                case 'maxDate':
                    optionsObj.maxDate = GPLimitDates.getDateValue( value, key, fieldId, formId, data );
                    break;
                case 'setsMinDateFor':
                case 'setsMaxDateFor':
                    optionsObj.onClose = function() {
                        onClose();
                        var $input = $( this );
                        var closeInterval = setInterval( function() {
                            if( ! $dp.is( ':visible' ) ) {
                                GPLimitDates.setMinMaxDate( $input, fieldId, formId, data );
                                clearInterval( closeInterval );
                            }
                        }, 200 );
                    };
                    break;
                case 'daysOfWeek':
                case 'exceptions':
                    optionsObj.beforeShowDay = function( date ) {
                        return GPLimitDates.isDateShown( date, data, fieldId );
                    };
                    break;
            }

        } );

        // initialize related functionality
        GPLimitDates.init( formId, fieldId, data );

        return optionsObj;
    } );

} )( jQuery );